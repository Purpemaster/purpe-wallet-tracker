// Express server placeholder
console.log('Server läuft...');