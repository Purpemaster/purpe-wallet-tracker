# PURPE Wallet Tracker

This project tracks SOL/USDC/PURPE donations live via Helius API and generates dynamic images and Facebook posts.